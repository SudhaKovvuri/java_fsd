package practice_project2;
public class AccessSpecifiers3  extends ProtectedAccessSpecifier{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AccessSpecifiers3 obj=new AccessSpecifiers3();
		obj.display();

	}

}
