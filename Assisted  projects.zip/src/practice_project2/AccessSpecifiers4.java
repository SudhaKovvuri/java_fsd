package practice_project2;

public class AccessSpecifiers4 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PublicAccessSpecifier obj = new PublicAccessSpecifier(); 
        obj.diplay();  




}
}
