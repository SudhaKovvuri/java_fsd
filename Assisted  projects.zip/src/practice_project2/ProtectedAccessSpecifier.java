package practice_project2;

public class ProtectedAccessSpecifier {

		protected void display()
		{
			System.out.println("protected acess specifier");
			


}
}
