package practice_project2;

public class PublicAccessSpecifier {
		public void diplay()
		{
			System.out.println("public acess specifier");
		}




}
