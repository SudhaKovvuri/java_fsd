package practice_project2;
class defAcessSpecifier
	{
		void display()
		{
			System.out.println("using default access specifier");
		}
	}

	public class AccessSpecifiers1 {

		public static void main(String[] args) {
			// TODO Auto-generated method stub
			defAcessSpecifier defobj=new defAcessSpecifier();
			defobj.display();
		}



}
