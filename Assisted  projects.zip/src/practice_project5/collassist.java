package practice_project5;
import java.util.*;

public class collassist {
	public static void main(String[] args) {
		
		
			System.out.println("ArrayList");
			ArrayList<String> city=new ArrayList<String>();   
		      city.add("HYDERABAD");
		      city.add("PUNE");    	   
		      System.out.println(city);  
			
		
		      System.out.println("\n");
		      System.out.println("Vector");
		      Vector<Integer> vec = new Vector<Integer>();
		      vec.addElement(50); 
		      vec.addElement(80); 
		      System.out.println(vec);
			
		
		      System.out.println("\n");
		      System.out.println("LinkedList");
		      LinkedList<String> names=new LinkedList<String>();  
		      names.add("RAM");  
		      names.add("SITA");  	      
		      Iterator<String> itr=names.iterator();  
		      while(itr.hasNext()){  
		       System.out.println(itr.next());  
		       
		       
		       System.out.println("\n");
		       System.out.println("HashSet");
		       HashSet<Integer> set=new HashSet<Integer>();  
		       set.add(111);  
		       set.add(112);  
		       set.add(113);
		       set.add(114);
		       System.out.println(set);
		       
		       System.out.println("\n");
		       System.out.println("LinkedHashSet");
		       LinkedHashSet<Integer> set2=new LinkedHashSet<Integer>();  
		       set2.add(10);  
		       set2.add(20);  
		       set2.add(30);
		       set2.add(40);	       
		       System.out.println(set2);
		      	} 
		      }  
}
		


