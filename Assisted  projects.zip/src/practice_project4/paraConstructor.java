package practice_project4;
class Student{
		int id;
		String name;
		Student(int i,String n)
		{
			id=i;
			name=n;
		}
		void display()
		{
			System.out.println(id+" "+name);
		}
	}
public class paraConstructor {
public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student s1=new Student(5,"ANU");
		Student s2=new Student(6,"UMA");
		s1.display();
		s2.display();

	}


}
