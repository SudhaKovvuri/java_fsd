package practice_project7;

public class innerClassAssisted {
 private String msg="hello how are you"; 
	 
	 class Inner{  
	  void hello(){System.out.println(msg+", welcome to java");}  
	 }  


	public static void main(String[] args) {

		innerClassAssisted obj=new innerClassAssisted();
		innerClassAssisted.Inner in=obj.new Inner();  
		in.hello();  
	}

}







