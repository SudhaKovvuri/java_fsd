package practice_project10;
import java.util.regex.*;
public class regexp {


		public static void main(String[] args) {
			// TODO Auto-generated method stub
			String pattern = "[a-z]+";
			String check = "Sudha";
			Pattern pobj = Pattern.compile(pattern);
			Matcher m = pobj.matcher(check);
			
			while (m.find())
		      	System.out.println( check.substring( m.start(), m.end() ) );
			}


}
